/******************************************************************************/
/* Important Fall 2022 CSCI 402 usage information:                            */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/*         53616c7465645f5fd1e93dbf35cbffa3aef28f8c01d8cf2ffc51ef62b26a       */
/*         f9bda5a68e5ed8c972b17bab0f42e24b19daa7bd408305b1f7bd6c7208c1       */
/*         0e36230e913039b3046dd5fd0ba706a624d33dbaa4d6aab02c82fe09f561       */
/*         01b0fd977b0051f0b0ce0c69f7db857b1b5e007be2db6d42894bf93de848       */
/*         806d9152bd5715e9                                                   */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

#include "globals.h"
#include "errno.h"
#include "util/debug.h"

#include "mm/mm.h"
#include "mm/page.h"
#include "mm/mman.h"

#include "vm/mmap.h"
#include "vm/vmmap.h"

#include "proc/proc.h"

/*
 * This function implements the brk(2) system call.
 *
 * This routine manages the calling process's "break" -- the ending address
 * of the process's "dynamic" region (often also referred to as the "heap").
 * The current value of a process's break is maintained in the 'p_brk' member
 * of the proc_t structure that represents the process in question.
 *
 * The 'p_brk' and 'p_start_brk' members of a proc_t struct are initialized
 * by the loader. 'p_start_brk' is subsequently never modified; it always
 * holds the initial value of the break. Note that the starting break is
 * not necessarily page aligned!
 *
 * 'p_start_brk' is the lower limit of 'p_brk' (that is, setting the break
 * to any value less than 'p_start_brk' should be disallowed).
 *
 * The upper limit of 'p_brk' is defined by the minimum of (1) the
 * starting address of the next occuring mapping or (2) USER_MEM_HIGH.
 * That is, growth of the process break is limited only in that it cannot
 * overlap with/expand into an existing mapping or beyond the region of
 * the address space allocated for use by userland. (note the presence of
 * the 'vmmap_is_range_empty' function).
 *
 * The dynamic region should always be represented by at most ONE vmarea.
 * Note that vmareas only have page granularity, you will need to take this
 * into account when deciding how to set the mappings if p_brk or p_start_brk
 * is not page aligned.
 *
 * You are guaranteed that the process data/bss region is non-empty.
 * That is, if the starting brk is not page-aligned, its page has
 * read/write permissions.
 *
 * If addr is NULL, you should "return" the current break. We use this to
 * implement sbrk(0) without writing a separate syscall. Look in
 * user/libc/syscall.c if you're curious.
 *
 * You should support combined use of brk and mmap in the same process.
 *
 * Note that this function "returns" the new break through the "ret" argument.
 * Return 0 on success, -errno on failure.
 */
int
do_brk(void *addr, void **ret)
{
        if (addr == NULL) {
                *ret = curproc->p_brk;
                dbg(DBG_PRINT, "(GRADING3A)\n");
                return 0;
        }

        uint32_t newadr = (uint32_t) addr;
        uint32_t cur_brk = (uint32_t) PAGE_ALIGN_UP(curproc->p_brk);
        uint32_t start_brk = (uint32_t) PAGE_ALIGN_UP(curproc->p_start_brk);
        
        if (newadr < (uint32_t) curproc->p_start_brk || newadr > USER_MEM_HIGH) {
                dbg(DBG_PRINT, "(GRADING3D 1)\n");
                return -ENOMEM;
        }

        // [****]
        vmarea_t *vma_start = vmmap_lookup(curproc->p_vmmap, ADDR_TO_PN(start_brk) - 1);
        vmarea_t *vma_cur = vmmap_lookup(curproc->p_vmmap, ADDR_TO_PN(cur_brk) - 1);

        uint32_t start_page = ADDR_TO_PN(PAGE_ALIGN_UP(curproc->p_start_brk));
        // variable: brk_page changed to curr_brk_page
        // variable: addr_page changed to next_brk_page
        uint32_t curr_brk_page = ADDR_TO_PN(PAGE_ALIGN_UP(curproc->p_brk)); // assign the page of the current break
        uint32_t next_brk_page =  ADDR_TO_PN(PAGE_ALIGN_UP(newadr)); // assign page of the next break

        int make_new_vma = 0;
        uint32_t new_vma_start = NULL;

        // if(vma_start == NULL){ 
        //         //vma_start would be NULL if brk_start is page aligned and therefore at the beginning of the vma of the
        //         // next VMA area which has not been created yet
        //         // create new vma in range
        //         make_new_vma = 1;
        //         new_vma_start = start_page;
        //         dbg(DBG_PRINT, "(GRADING3???do_brk3)\n");


        // }
        // else 
        if((vma_start == vma_cur) && (next_brk_page > start_page)){
                // check if the vma area is the same for the start_brk and the 
                // curr break. if it is and the address of the new break page you want to set
                // is beyond the page that holds the start_brk/curr_brk, you need to create
                // a new vma area
                make_new_vma = 1;
                new_vma_start = start_page;
                dbg(DBG_PRINT, "(GRADING3A)\n");

        }
        
        if(make_new_vma){
                uint32_t npages = next_brk_page - new_vma_start; // Revisit: + 1
                // vmarea_t *new_vma; // putting this here for debugging, we shouldn't need it
                if (!vmmap_is_range_empty(curproc->p_vmmap, new_vma_start, npages)) { 
                        dbg(DBG_PRINT, "(GRADING3D 2)\n");
                        return -ENOMEM; // we cannot extend the region by this many pages if there is memory claimed
                }
                // int retval = 
                do_mmap(PN_TO_ADDR(new_vma_start), npages*PAGE_SIZE, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANON, NULL, 0, NULL);
                // if(retval < 0){
                //         dbg(DBG_PRINT, "(GRADING3???do_brk6)\n");

                //         return retval;
                // }
                dbg(DBG_PRINT, "(GRADING3A)\n");

                // vmmap_map(curproc->p_vmmap, NULL, new_vma_start, npages, PROT_READ|PROT_WRITE, MAP_PRIVATE, 0, VMMAP_DIR_HILO, &new_vma);
        }
        else{
                if(next_brk_page > curr_brk_page){
                        uint32_t npages = next_brk_page - curr_brk_page;
                        if (!vmmap_is_range_empty(curproc->p_vmmap, curr_brk_page, npages)) { 
                                dbg(DBG_PRINT, "(GRADING3D 2)\n");
                                return -ENOMEM; // we cannot extend the region by this many pages if there is memory claimed
                       }
                       vma_cur->vma_end = next_brk_page;
                       dbg(DBG_PRINT, "(GRADING3A)\n");

                }
                else if(next_brk_page < curr_brk_page){
                        do_munmap(PN_TO_ADDR(next_brk_page), (curr_brk_page - next_brk_page) * PAGE_SIZE);
                        // vmmap_remove(curproc->p_vmmap, next_brk_page, curr_brk_page - next_brk_page);
                        dbg(DBG_PRINT, "(GRADING3D 1)\n");

                }
                dbg(DBG_PRINT, "(GRADING3A)\n");

        }

        *ret = addr;
        curproc->p_brk = addr;
        dbg(DBG_PRINT, "(GRADING3A)\n");       
        return 0;
        
        // // if next_brk_page > brk_page
        // if(next_brk_page > curr_brk_page){

             
                
        //         if (!vmmap_is_range_empty(curproc->p_vmmap, curr_brk_page, npages)) { 
        //                 dbg(DBG_PRINT, "(GRADING3???do_brk4)\n");
        //                 return -ENOMEM; // we cannot extend the region by this many pages if there is memory claimed
        //         }

        //         // check if we need to create a new vmarea
        //         if(curr_brk_page == start_page){
        //                 // create the new vmarea
        //                 uint32_t npages = addr_page + 1 - vma->vma_end;
        //                 vmarea_t *new_vma; // putting this here for debugging, we shouldn't need it
        //                 vmmap_map(curproc->p_vmmap, NULL, vma->vma_end, npages, vma->vma_prot, vma->vma_flags, 0, VMMAP_DIR_HILO, &new_vma);
        //         }
        // }

        // // if addr_page < curr_brk_page

        // if (newadr > cur_brk) {





        //         // page align down the new address, go up one page, and determine how many pages needed for the new vmarea
        //         if (!vmmap_is_range_empty(curproc->p_vmmap, curr_brk_page, next_brk_page - curr_brk_page)) { 
        //                 dbg(DBG_PRINT, "(GRADING3???do_brk4)\n");
        //                 return -ENOMEM; // we cannot extend the region by this many pages if there is memory claimed
        //         }

        //         vma->vma_end = next_brk_page + 1; // end at the new address
        //          dbg(DBG_PRINT, "(GRADING3???do_brk5)\n");
        // } else {
        //         vmmap_remove(curproc->p_vmmap, next_brk_page, curr_brk_page - next_brk_page);
        //         dbg(DBG_PRINT, "(GRADING3???do_brk6)\n");
        // }

        // curproc->p_brk = addr;
        
}
