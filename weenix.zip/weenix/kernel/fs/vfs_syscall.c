/******************************************************************************/
/* Important Fall 2022 CSCI 402 usage information:                            */
/*                                                                            */
/* This fils is part of CSCI 402 kernel programming assignments at USC.       */
/*         53616c7465645f5fd1e93dbf35cbffa3aef28f8c01d8cf2ffc51ef62b26a       */
/*         f9bda5a68e5ed8c972b17bab0f42e24b19daa7bd408305b1f7bd6c7208c1       */
/*         0e36230e913039b3046dd5fd0ba706a624d33dbaa4d6aab02c82fe09f561       */
/*         01b0fd977b0051f0b0ce0c69f7db857b1b5e007be2db6d42894bf93de848       */
/*         806d9152bd5715e9                                                   */
/* Please understand that you are NOT permitted to distribute or publically   */
/*         display a copy of this file (or ANY PART of it) for any reason.    */
/* If anyone (including your prospective employer) asks you to post the code, */
/*         you must inform them that you do NOT have permissions to do so.    */
/* You are also NOT permitted to remove or alter this comment block.          */
/* If this comment block is removed or altered in a submitted file, 20 points */
/*         will be deducted.                                                  */
/******************************************************************************/

/*
 *  FILE: vfs_syscall.c
 *  AUTH: mcc | jal
 *  DESC:
 *  DATE: Wed Apr  8 02:46:19 1998
 *  $Id: vfs_syscall.c,v 1.2 2018/05/27 03:57:26 cvsps Exp $
 */

#include "kernel.h"
#include "errno.h"
#include "globals.h"
#include "fs/vfs.h"
#include "fs/file.h"
#include "fs/vnode.h"
#include "fs/vfs_syscall.h"
#include "fs/open.h"
#include "fs/fcntl.h"
#include "fs/lseek.h"
#include "mm/kmalloc.h"
#include "util/string.h"
#include "util/printf.h"
#include "fs/stat.h"
#include "util/debug.h"

/*
 * Syscalls for vfs. Refer to comments or man pages for implementation.
 * Do note that you don't need to set errno, you should just return the
 * negative error code.
 */

/* To read a file:
 *      o fget(fd)
 *      o call its virtual read vn_op
 *      o update f_pos
 *      o fput() it
 *      o return the number of bytes read, or an error
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        fd is not a valid file descriptor or is not open for reading.
 *      o EISDIR
 *        fd refers to a directory.
 *
 * In all cases, be sure you do not leak file refcounts by returning before
 * you fput() a file that you fget()'ed.
 */
int
do_read(int fd, void *buf, size_t nbytes)
{
        if (fd == -1){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF; 
        }
        file_t *file = fget(fd);
        if(file == NULL){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF;
        }
        if (!(file->f_mode & FMODE_READ)) {
                fput(file); 
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF;
        }

        // ERROR handling; check that the file isn't a directory
        vnode_t *file_vnode = file->f_vnode;
        if (S_ISDIR(file_vnode->vn_mode)) {
                fput(file); 
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EISDIR;
        }
        if (file->f_vnode->vn_ops->read==NULL){ //don't think this is ever executed, may need to remove
                fput(file); 
                dbg(DBG_PRINT, "(GRADING3???do_read1)\n");
                return -EBADF; 
        }
        int num_bytes_read = file->f_vnode->vn_ops->read(file_vnode, file->f_pos, buf, nbytes);
        file->f_pos += num_bytes_read; 
        fput(file);
        // dbg(DBG_PRINT, "(GRADING2A)\n");
        return num_bytes_read;
}


/* Very similar to do_read.  Check f_mode to be sure the file is writable.  If
 * f_mode & FMODE_APPEND, do_lseek() to the end of the file, call the write
 * vn_op, and fput the file.  As always, be mindful of refcount leaks.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        fd is not a valid file descriptor or is not open for writing.
 */
int
do_write(int fd, const void *buf, size_t nbytes)
{
        if (fd == -1){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF; 
        }
        file_t *file = fget(fd);
        if(file == NULL){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF;
        }
        if (!(file->f_mode & FMODE_WRITE)) {
                fput(file); 
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF;
        }

        if (file->f_mode & FMODE_APPEND) {
                int ret_val = do_lseek(fd, 0, SEEK_END);
                if (ret_val < 0){
                        fput(file); 
                        dbg(DBG_PRINT, "(GRADING3???do_write1)\n");
                        return ret_val; 
                }
                // dbg(DBG_PRINT, "(GRADING2B)\n");
        }
        vnode_t *file_vnode = file->f_vnode;
        
        if (file->f_vnode->vn_ops->write == NULL){ 
                fput(file);
                dbg(DBG_PRINT, "(GRADING3???do_write2)\n");
                return -EBADF;
        }

        int num_bytes_written = file->f_vnode->vn_ops->write(file_vnode, file->f_pos, buf, nbytes);
        file->f_pos += num_bytes_written;
        fput(file);

        KASSERT((S_ISCHR(file->f_vnode->vn_mode)) || 
                (S_ISBLK(file->f_vnode->vn_mode)) ||
                ((S_ISREG(file->f_vnode->vn_mode)) && 
                (file->f_pos <= file->f_vnode->vn_len))); /* cursor must not go past end of file for these file types */
        
        // dbg(DBG_PRINT, "(GRADING2A 3.a)\n");
        return num_bytes_written;
}

/*
 * Zero curproc->p_files[fd], and fput() the file. Return 0 on success
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        fd isn't a valid open file descriptor.
 */
int
do_close(int fd)
{       
        if (fd == -1){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF; 
        }
        file_t *file = fget(fd);
        if (file == NULL) {
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF;
        }
        fput(file);
        curproc->p_files[fd] = NULL;
        fput(file);

        // dbg(DBG_PRINT, "(GRADING2A)\n");
        return 0;
}

/* To dup a file:
 *      o fget(fd) to up fd's refcount
 *      o get_empty_fd()
 *      o point the new fd to the same file_t* as the given fd
 *      o return the new file descriptor
 *
 * Don't fput() the fd unless something goes wrong.  Since we are creating
 * another reference to the file_t*, we want to up the refcount.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        fd isn't an open file descriptor.
 *      o EMFILE
 *        The process already has the maximum number of file descriptors open
 *        and tried to open a new one.
 */
int
do_dup(int fd)
{
        // get the file
        // this increases the ref count by 1
        // did we initialize "p_files" to NULL??
        if (fd == -1){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF; 
        }
        file_t *file = fget(fd);
        
        // error check: make sure the file descriptor is open and the file descriptor
        // is not within an invalid range
        if (file == NULL) {
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF;
        }
        
        // error check: make sure you are not out of empty file descriptors
        int new_fd = get_empty_fd(curproc); 
        if (new_fd < 0) {
                fput(file); 

                dbg(DBG_PRINT, "(GRADING3???do_dup1)\n");
                return new_fd;
        }

        // Is this how you set a file in the file table?
        // set the new file descriptor to point to the same file that fd points to
        curproc->p_files[new_fd] = file;

        // dbg(DBG_PRINT, "(GRADING2B)\n");
        return new_fd;
        //NOT_YET_IMPLEMENTED("VFS: do_dup");
        //return -1;
}

/* Same as do_dup, but insted of using get_empty_fd() to get the new fd,
 * they give it to us in 'nfd'.  If nfd is in use (and not the same as ofd)
 * do_close() it first.  Then return the new file descriptor.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        ofd isn't an open file descriptor, or nfd is out of the allowed
 *        range for file descriptors.
 */
int
do_dup2(int ofd, int nfd)
{
        // get the file
        // this increases the ref count by 1
        // did we initialize "p_files" to NULL??
        if (ofd == -1){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF; 
        }
        file_t *file = fget(ofd);
        
        // error check: make sure the file descriptor is open and the file descriptor
        // is not within an invalid range
        if (file == NULL) {
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF;
        }

        // check that the nfd is within a valid range
        if (nfd < 0 || nfd >= NFILES) {
            fput(file);
            
            dbg(DBG_PRINT, "(GRADING3D 1)\n");
            return -EBADF;
        }

        // check that the nfd is within a valid range
        if (nfd < 0 || nfd >= NFILES) {
            fput(file);
            
            dbg(DBG_PRINT, "(GRADING3???do_dup2_2)\n");
            return -EBADF;
        }

        // if the old file descriptor equals the new file descriptor, don't do anything, 
        // just return
        if (ofd == nfd) {
                fput(file);

                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return nfd;
        }

        // check that the nfd does not have a file open already
        // do close will either close the file descriptor or not do anything and return an error
        do_close(nfd);
        curproc->p_files[nfd] = file;

        // dbg(DBG_PRINT, "(GRADING2B)\n");
        return nfd;
        
        //NOT_YET_IMPLEMENTED("VFS: do_dup2");
}

/*
 * This routine creates a special file of the type specified by 'mode' at
 * the location specified by 'path'. 'mode' should be one of S_IFCHR or
 * S_IFBLK (you might note that mknod(2) normally allows one to create
 * regular files as well-- for simplicity this is not the case in Weenix).
 * 'devid', as you might expect, is the device identifier of the device
 * that the new special file should represent.
 *
 * You might use a combination of dir_namev, lookup, and the fs-specific
 * mknod (that is, the containing directory's 'mknod' vnode operation).
 * Return the result of the fs-specific mknod, or an error.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EINVAL
 *        mode requested creation of something other than a device special
 *        file.
 *      o EEXIST
 *        path already exists.
 *      o ENOENT
 *        A directory component in path does not exist.
 *      o ENOTDIR
 *        A component used as a directory in path is not, in fact, a directory.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 */
int
do_mknod(const char *path, int mode, unsigned devid)
{
        /*
         * Pseudo-code:
         * 1.) Check that the device is a special device
         * 2.) Make sure that the path is valid and directory doesn't already exist
         * 3.) Calls mknod from the resulting vnode that is found by dir_namev
         * Misc:
         * - need to make sure that the reference count and parent pointers are set when creating
         * - not exactly sure how to go about checking the type of the d
         */
        
        
        // check that the mode passed in is for a special device, Revisit: Need to confirm that this would be tested
        // in grading guidelines
        // found the mode function in stat.h --> unsure if this is the correct way to run the macro or the correct way to 
        // check the compatibility of "mode"
        if ((!S_ISCHR(mode)) && (!S_ISBLK(mode))) {
                dbg(DBG_PRINT, "(GRADING3???do_mknod0)\n");
                return -EINVAL;
        }
        
        // check that the path to the directory that we will be creating the device in is valid

        const char *name[MAXPATHLEN];
        size_t namelen;
        vnode_t *dir_vnode;
        vnode_t *child;
        int dir_namev_err = dir_namev(path, &namelen, name, NULL, &dir_vnode);
        if (dir_namev_err != 0) {
                // this will return either -ENOTDIR or -ENOENT
                dbg(DBG_PRINT, "(GRADING3???do_mknod1)\n");
                return dir_namev_err;
        } 
        else if (lookup(dir_vnode, *name, namelen, &child) == 0) {
                vput(dir_vnode); 
                vput(child); // found an already existing reference, decrement the count
                //vput(dir_namev); 
                dbg(DBG_PRINT, "(GRADING3???do_mknod2)\n");
                return -EEXIST;
        }
        KASSERT(NULL != dir_vnode->vn_ops->mknod);
        // dbg(DBG_PRINT, "(GRADING2A 3.b)\n");

        int retval = dir_vnode->vn_ops->mknod(dir_vnode, *name, namelen, mode, devid);
        vput(dir_vnode); // this is fine, tested
        // dbg(DBG_PRINT, "(GRADING2A)\n");
        return retval;
        
        //NOT_YET_IMPLEMENTED("VFS: do_mknod");
        //return -1;
}

/* Use dir_namev() to find the vnode of the dir we want to make the new
 * directory in.  Then use lookup() to make sure it doesn't already exist.
 * Finally call the dir's mkdir vn_ops. Return what it returns.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EEXIST
 *        path already exists.
 *      o ENOENT
 *        A directory component in path does not exist.
 *      o ENOTDIR
 *        A component used as a directory in path is not, in fact, a directory.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 */
int
do_mkdir(const char *path)
{
        // NOT_YET_IMPLEMENTED("VFS: do_mkdir");
        const char *name[MAXPATHLEN];
        size_t namelen;
        vnode_t *dir_vnode;
        vnode_t *child;
        int dir_namev_err = dir_namev(path, &namelen, name, NULL, &dir_vnode);

        if (dir_namev_err != 0) {
                // this will return either -ENOTDIR or -ENOENT
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return dir_namev_err;
        }else if (0 == lookup(dir_vnode, *name, namelen, &child)) {
                vput(dir_vnode); 
                vput(child); // found an already existing reference, decrement the count
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EEXIST;
        }else if (namelen==0){
                vput(dir_vnode); 
                // dbg(DBG_PRINT, "(GRADING2A)\n");
                return -EEXIST; // check if this does anythign again
        }

        KASSERT(NULL != dir_vnode->vn_ops->mkdir);
        // dbg(DBG_PRINT, "(GRADING2A 3.c)\n");

        int retval = dir_vnode->vn_ops->mkdir(dir_vnode, *name, namelen);
        vput(dir_vnode);

        // increment the refcount of the newly created directory???
        // vnode_t *new_dir;
        // lookup(dir_vnode, *name, namelen, &new_dir);

        // dbg(DBG_PRINT, "(GRADING2A)\n");
        // check if #references to dir_vnode goes up from before above call 
        return retval;
}

/* Use dir_namev() to find the vnode of the directory containing the dir to be
 * removed. Then call the containing dir's rmdir v_op. The rmdir v_op will
 * return an error if the dir to be removed does not exist or is not empty, so
 * you don't need to worry about that here. Return the value of the v_op,
 * or an error.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EINVAL
 *        path has "." as its final component.
 *      o ENOTEMPTY
 *        path has ".." as its final component.
 *      o ENOENT
 *        A directory component in path does not exist.
 *      o ENOTDIR
 *        A component used as a directory in path is not, in fact, a directory.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 */
int
do_rmdir(const char *path)
{
        // Revisit: ask about special name characters
        const char *name[MAXPATHLEN];
        size_t namelen;
        vnode_t *dir_vnode;

        int dir_namev_err = dir_namev(path, &namelen, name, NULL, &dir_vnode);
        KASSERT(NULL != dir_vnode->vn_ops->rmdir);
        // dbg(DBG_PRINT, "(GRADING2A 3.d)\n");
        
        if (dir_namev_err != 0) 
        {
                // this will return either -ENOTDIR or -ENOENT
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return dir_namev_err;
        }
        if (namelen==0){ 
                vput(dir_vnode);
                dbg(DBG_PRINT, "(GRADING3???rmdir_1)\n");
                return -EINVAL; 
        }
        else if ((namelen == 2) && !strncmp(*name, "..", 2) ) {
                vput(dir_vnode);
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -ENOTEMPTY;
        }
        else if((namelen == 1) && !strncmp(*name, ".", 1)){
                vput(dir_vnode);
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EINVAL;
        }

        KASSERT(NULL != dir_vnode->vn_ops->rmdir);
        // dbg(DBG_PRINT, "(GRADING2A 3.d)\n");
        // dbg(DBG_PRINT, "(GRADING2B)\n");
        
        //vput(dir_vnode);
        int retval = dir_vnode->vn_ops->rmdir(dir_vnode, *name, namelen);
        vput(dir_vnode);
        // vput(dir_vnode); // REVISIT: really a shot in the dark here
        // dbg(DBG_PRINT, "(GRADING2B)\n");
        return retval;
        // vputs not causing an issue here either
        //NOT_YET_IMPLEMENTED("VFS: do_rmdir");
        //return -1;
}

/*
 * Similar to do_rmdir, but for files.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EPERM
 *        path refers to a directory.
 *      o ENOENT
 *        Any component in path does not exist, including the element at the
 *        very end.
 *      o ENOTDIR
 *        A component used as a directory in path is not, in fact, a directory.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 */
int
do_unlink(const char *path)
{
        
        const char *name[MAXPATHLEN];
        size_t namelen;
        vnode_t *dir_vnode, *child_vnode;

        int dir_error = dir_namev(path, &namelen, name, NULL, &dir_vnode);
        if (dir_error < 0) {
                // dbg(DBG_PRINT, "(GRADING2B)\n"); 
                return dir_error;
        }
        

        // do lookup to check that the file exists in dir
        int lookup_err = lookup(dir_vnode, *name, namelen, &child_vnode);
        if (lookup_err < 0) {
                vput(dir_vnode);
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return lookup_err;
        }
        

        // check that child is not a directory
        if (S_ISDIR(child_vnode->vn_mode)) {
                vput(child_vnode);
                vput(dir_vnode);
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EPERM;
        }
        
        KASSERT(NULL != dir_vnode->vn_ops->unlink);
        // dbg(DBG_PRINT, "(GRADING2A 3.e)\n"); 
        // dbg(DBG_PRINT, "(GRADING2B)\n"); 

        int retval = dir_vnode->vn_ops->unlink(dir_vnode, *name, namelen);
        vput(child_vnode);
        vput(dir_vnode);
        
        // dbg(DBG_PRINT, "(GRADING2B)\n");
        return retval;
        //return dir_vnode->vn_ops->unlink(dir_vnode, *name, namelen);
        
        
        //NOT_YET_IMPLEMENTED("VFS: do_unlink");

}

/* To link:
 *      o open_namev(from)
 *      o dir_namev(to)
 *      o call the destination dir's (to) link vn_ops.
 *      o return the result of link, or an error
 *
 * Remember to vput the vnodes returned from open_namev and dir_namev.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EEXIST
 *        to already exists.
 *      o ENOENT
 *        A directory component in from or to does not exist.
 *      o ENOTDIR
 *        A component used as a directory in from or to is not, in fact, a
 *        directory.
 *      o ENAMETOOLONG
 *        A component of from or to was too long.
 *      o EPERM
 *        from is a directory.
 */
int
do_link(const char *from, const char *to)
{
        
        vnode_t *old_vnode;

        // what do we put into the "flags" variable
        int open_err = open_namev(from, 0, &old_vnode, NULL);
        // come back to this to see if there are other errors to account for
        if (open_err < 0) {
                // dbg(DBG_PRINT, "(GRADING2B)\n"); 
                return open_err;
        }
        if (S_ISDIR(old_vnode->vn_mode)) {
                vput(old_vnode);

                dbg(DBG_PRINT, "(GRADING3D 1)\n"); // may need to add subsection or something for self checks 
                return -EPERM;
        }

        const char *name[MAXPATHLEN];
        size_t namelen;
        vnode_t *dir_vnode;

        int dir_err = dir_namev(to, &namelen, name, NULL, &dir_vnode);
        if (dir_err < 0) {
                vput(old_vnode);

                // dbg(DBG_PRINT, "(GRADING2B)\n"); 
                return dir_err;
        }

        int retval = dir_vnode->vn_ops->link(old_vnode, dir_vnode, *name, namelen);
        vput(dir_vnode);
        vput(old_vnode);
        if (retval < 0)
        {
                // revisit: put dir_vnode here as well?

                // dbg(DBG_PRINT, "(GRADING2B)\n"); 
                return retval;
        }
       

        dbg(DBG_PRINT, "(GRADING3D 1)\n"); 

        return 0;
        // //NOT_YET_IMPLEMENTED("VFS: do_link");
        // return -1;
}

/*      o link newname to oldname
 *      o unlink oldname
 *      o return the value of unlink, or an error
 *
 * Note that this does not provide the same behavior as the
 * Linux system call (if unlink fails then two links to the
 * file could exist).
 */
int
do_rename(const char *oldname, const char *newname)
{
        
        int link_err = do_link(oldname, newname);
        if(link_err <0){
                // dbg(DBG_PRINT, "(GRADING2B)\n");

                return link_err;
        }
        link_err = do_unlink(oldname);

        // NOT_YET_IMPLEMENTED("VFS: do_rename");
        // panic("do_rename success is not tested for grading guidelines\n");
        dbg(DBG_PRINT, "(GRADING3???do_rename1)\n");  
        return link_err;
        // return -1;
}

/* Make the named directory the current process's cwd (current working
 * directory).  Don't forget to down the refcount to the old cwd (vput()) and
 * up the refcount to the new cwd (open_namev() or vget()). Return 0 on
 * success.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o ENOENT
 *        path does not exist.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 *      o ENOTDIR
 *        A component of path is not a directory.
 */
int
do_chdir(const char *path)
{
        /*
         * Psuedocode:
         *
         * 1.) Validate the path exists (dir_namev)
         * 2.) Change the cwd in process control block of current thread
         * 3.) Decrement the ref count of old directory (vput) 
         * 4.) increment the ref count of new cwd
         * 5.) return 0
         */

        const char *name[MAXPATHLEN];
        size_t namelen;
        vnode_t *dir_vnode, *child_vnode;
        // Revisit: needs another argument 
        int dir_error = dir_namev(path, &namelen, name, NULL,  &dir_vnode);

        if(dir_error){
                dbg(DBG_PRINT, "(GRADING3???do_chdir0)\n");
                return dir_error;
        }

        int lookup_err;
        if ((lookup_err = lookup(dir_vnode, *name, namelen, &child_vnode)) < 0){
                vput(dir_vnode); 
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return lookup_err;
        }
        vput(dir_vnode);
        dir_vnode = child_vnode;

        if(!S_ISDIR(dir_vnode->vn_mode)){
                vput(dir_vnode);
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -ENOTDIR;
        }

        vput(curproc->p_cwd);
        curproc->p_cwd = dir_vnode;
        // dbg(DBG_PRINT, "(GRADING2B)\n");

        // NOT_YET_IMPLEMENTED("VFS: do_chdir");
        return 0;
}

/* Call the readdir vn_op on the given fd, filling in the given dirent_t*.
 * If the readdir vn_op is successful, it will return a positive value which
 * is the number of bytes copied to the dirent_t.  You need to increment the
 * file_t's f_pos by this amount.  As always, be aware of refcounts, check
 * the return value of the fget and the virtual function, and be sure the
 * virtual function exists (is not null) before calling it.
 *
 * Return either 0 or sizeof(dirent_t), or -errno.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        Invalid file descriptor fd.
 *      o ENOTDIR
 *        File descriptor does not refer to a directory.
 */
int
do_getdent(int fd, struct dirent *dirp)
{        
        if (fd == -1){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF; 
        }
        file_t *file = fget(fd);
        // make sure file descriptor is open
        if (file == NULL) {
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF;
        }
        
        // Check to make sure that the file is a directory
        if(!S_ISDIR(file->f_vnode->vn_mode)){
                fput(file); 
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -ENOTDIR;
        }

        if(file->f_vnode->vn_ops->readdir == NULL){
                fput(file); 
                dbg(DBG_PRINT, "(GRADING3???do_getdent1)\n");
                return -EBADF; // not sure if this is what we should return but not specified...
        }

        int nbytes = 0;
        int bytes_read = file->f_vnode->vn_ops->readdir(file->f_vnode, file->f_pos, dirp);
        file->f_pos+= bytes_read;
        int retval = 0;
        if(bytes_read){
                retval = sizeof(dirent_t);
                // dbg(DBG_PRINT, "(GRADING2B)\n");
        }

        fput(file); // added last
        // dbg(DBG_PRINT, "(GRADING2B)\n");
        return  retval;
}

/*
 * Modify f_pos according to offset and whence.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o EBADF
 *        fd is not an open file descriptor.
 *      o EINVAL
 *        whence is not one of SEEK_SET, SEEK_CUR, SEEK_END; or the resulting
 *        file offset would be negative.
 */
int
do_lseek(int fd, int offset, int whence)
{
        if (fd == -1){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF; 
        }
        file_t *file = fget(fd);
        if (file == NULL) {
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EBADF;
        }

        // int (*stat)(struct vnode *vnode, struct stat *buf);
        // struct stat buf;
        // struct vnode *f_vnode = file->f_vnode;
        // file->f_vnode->vn_ops->stat(f_vnode, &buf);
        
        int file_size = file->f_vnode->vn_len;        
        int compareTo;
        if(whence == SEEK_SET){
                compareTo = 0;
                // dbg(DBG_PRINT, "(GRADING2B)\n");
        }
        else if(whence == SEEK_CUR){
                compareTo = file->f_pos;
                // dbg(DBG_PRINT, "(GRADING2B)\n");
        }
        else if(whence == SEEK_END){
                compareTo = file_size;
                // dbg(DBG_PRINT, "(GRADING2B)\n");
        }
        else{
                fput(file);
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EINVAL;
        }
        if((offset + compareTo < 0)){ // || (offset + compareTo > file_size)){
                fput(file);
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EINVAL;
        }

        file->f_pos = offset + compareTo;
        fput(file);
        // NOT_YET_IMPLEMENTED("VFS: do_lseek");
        // dbg(DBG_PRINT, "(GRADING2B)\n");
        return file->f_pos;
}

/*
 * Find the vnode associated with the path, and call the stat() vnode operation.
 *
 * Error cases you must handle for this function at the VFS level:
 *      o ENOENT
 *        A component of path does not exist.
 *      o ENOTDIR
 *        A component of the path prefix of path is not a directory.
 *      o ENAMETOOLONG
 *        A component of path was too long.
 *      o EINVAL
 *        path is an empty string.
 */
int
do_stat(const char *path, struct stat *buf)
{

        // NOT_YET_IMPLEMENTED("VFS: do_stat");
        // call dir_namev on path

        if (strlen(path) == 0){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return -EINVAL; 
        }
        const char *name[MAXPATHLEN];
        size_t namelen;
        vnode_t *dir_vnode;
        // Revisit: Missing result vnode in func call 
        int dir_error = dir_namev(path, &namelen, name, NULL, &dir_vnode);

        if(dir_error != 0){
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return dir_error;
        }

        vnode_t *res_vnode;
        if(namelen == 0){
                // this happens if we are at root, and maybe some other times idk
                int ret_val = dir_vnode->vn_ops->stat(dir_vnode, buf);
                vput(dir_vnode);
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return ret_val;
        }
        
        int lookup_err = lookup(dir_vnode, *name, namelen, &res_vnode);
        if(lookup_err != 0){
                vput(dir_vnode); 
                // dbg(DBG_PRINT, "(GRADING2B)\n");
                return lookup_err;
        }
        
        // call lookup on the name with name length returned (not sure, can this be called on files)
        KASSERT(NULL != res_vnode->vn_ops->stat);
        // dbg(DBG_PRINT, "(GRADING2A 3.f)\n");
        // dbg(DBG_PRINT, "(GRADING2B)\n");

        int ret_val = res_vnode->vn_ops->stat(res_vnode, buf);
        vput(dir_vnode); 
        vput(res_vnode); 
        // dbg(DBG_PRINT, "(GRADING2A)\n");
        return ret_val; 
        
}

#ifdef __MOUNTING__
/*
 * Implementing this function is not required and strongly discouraged unless
 * you are absolutely sure your Weenix is perfect.
 *
 * This is the syscall entry point into vfs for mounting. You will need to
 * create the fs_t struct and populate its fs_dev and fs_type fields before
 * calling vfs's mountfunc(). mountfunc() will use the fields you populated
 * in order to determine which underlying filesystem's mount function should
 * be run, then it will finish setting up the fs_t struct. At this point you
 * have a fully functioning file system, however it is not mounted on the
 * virtual file system, you will need to call vfs_mount to do this.
 *
 * There are lots of things which can go wrong here. Make sure you have good
 * error handling. Remember the fs_dev and fs_type buffers have limited size
 * so you should not write arbitrary length strings to them.
 */
int
do_mount(const char *source, const char *target, const char *type)
{
        NOT_YET_IMPLEMENTED("MOUNTING: do_mount");
        return -EINVAL;
}

/*
 * Implementing this function is not required and strongly discouraged unless
 * you are absolutley sure your Weenix is perfect.
 *
 * This function delegates all of the real work to vfs_umount. You should not worry
 * about freeing the fs_t struct here, that is done in vfs_umount. All this function
 * does is figure out which file system to pass to vfs_umount and do good error
 * checking.
 */
int
do_umount(const char *target)
{
        NOT_YET_IMPLEMENTED("MOUNTING: do_umount");
        return -EINVAL;
}
#endif
